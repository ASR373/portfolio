# harshish.dev

[![Netlify Status](https://api.netlify.com/api/v1/badges/84e06d2e-3760-49ae-b2af-ecfb6c0bcc73/deploy-status)](https://app.netlify.com/projects/harshish/deploys)

Personal portfolio. React 19 + Three.js + Framer Motion, styled with vanilla CSS and deployed on Netlify.

```bash
npm install && npm run dev
```

*Built with late-night CSS debugging.*
